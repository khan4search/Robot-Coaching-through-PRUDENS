const app = require('express')();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const net = require("net");
const port = process.env.PORT || 3000;
var express = require('express');
var cache = new Object();
var lastReq;
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.use(express.static(__dirname + '/'));

var globalSocket;
var useMemory;
const server = net.createServer((socket)=>{
  globalSocket = socket;
  globalSocket.write("Hello From Server!")
  var input = ""; 
  socket.on("data",(data)=>{
      input +=data.toString()
    
    
      for (let i = 0; i < input.length; i++) {
      
        if(data.toString().charCodeAt(i)== 13){
          lastReq = input;
      if(useMemory && cache[lastReq]){
        globalSocket.write(cache[lastReq])
      }else{

        io.emit('context', input); 
      }
      input =""
      }
    }; 

  
  });
  socket.on("close",()=>{
      console.log("Connection closed.!!!")
  })

});
server.listen(1258);
io.on('connection', (socket) => {
  socket.on('ServerResponse', msg => {
    msg="{"+msg+"}"
    console.log(msg)
    globalSocket.write(msg)
    if(useMemory)
      cache[lastReq]=msg;
  });
  socket.on('clearMemory', msg => {
    cache = new Object();
  });
  socket.on('useMemory', msg => {
    console.log(msg)
    useMemory = msg;
  });
  
});

http.listen(port, () => {
  console.log(`Socket.IO server running at http://localhost:${port}/`);
});
